/*******************************************************************************
 * Copyright (c) 2016
 * The National University of Singapore, Xtra Group
 *
 * Author: Zeke Wang (wangzeke638 AT gmail.com)
 * Import form Cagri Balkesen.
 * Description: Provides cpu mapping utility function.
 * Only the function get_cpu_id is used by the user........
 *******************************************************************************/


